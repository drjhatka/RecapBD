
  <!-- left menu -->
      <div class="col-md-2 sidebar">
          <ul>
              <li><a href="{{ route('dashboard') }}">Home</a></li>
              <li><a href="{{ route('add.news') }}">Add News</a></li>
              <li><a href="{{ route('show.news') }}">View News</a></li>
              <li><a href="{{ route('add.editorial') }}">Add Editorial</a></li>
              <li><a href="{{ route('view.editorials') }}">View Editorials</a></li>
              <li><a href="{{ route('logout') }}">Logout</a></li>
          </ul>
      </div>

