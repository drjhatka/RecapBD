<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <?php
        $news = News::find($id);
    ?>
    <div class="row">
        <div class="col-md-12">
           <h4>
               <?php echo e($news->title); ?> <br> <hr>
            </h4>
        </div>

        <div class="col-md-12 bg-dark">
             <img class="img-fluid img-bordered" style="" src="<?php echo e($news->image_path); ?>" alt="">
        </div>

        <div class="col-md-3">
            <hr>
            Created: <?php echo e($news->created_at); ?>

        </div>
        <div class="col-md-3">
                <hr>
                Updated: <?php echo e($news->updated_at); ?>

        </div>
        <div class="col-md-3">
                <hr>
                Posted By: <?php echo e($news->posted_by); ?>

        </div>

        <div class="col-md-12 mt-3">
            <?php echo e($news->story); ?>

        </div>

        <div class="col-md-12 mt-3">
            <hr>
               Category : <?php echo e($news->category->description); ?>

        </div>

        <div class="col-md-12">
                <hr>
                    <h4>TAGS LIST</h4>
            </div>
        <div class="col-md-12">
            <hr>
            <h4>RELATED NEWS / MORE NEWS FROM THIS CATEGORY</h4>
        </div>
        <div class="col-md-12">
            <hr>
                <h4>COMMENTS</h4>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>