<?php $__env->startSection('content'); ?>

    <div class="col-md-10" style="	background:#D1EEEE">

            <div class="col-md-11 ml-1 bg-success text-white card-header">
                    News Management
            </div>

            <div class="col-md-12 mt-2">
                <a href="<?php echo e(route('show.news')); ?>">
                    <span class="badge badge-danger py-2"> <i class="fa fa-hand-o-left fa-2x"></i> Go Back</span>

                </a>
            </div>
            <?php if(Session::has('search_empty')): ?>
                <?php
                    $msg= Session::get('search_empty');
                ?>
                    <div class="col-md-12  mt-2 alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($msg); ?></strong>
                    </div>
            <?php endif; ?>

            <div class="col-md-11 ml-1  card-body">

                <?php echo Form::open(['route'=>'search', 'method'=>'get']); ?>

                <div class="row">
                            <div class="col-md-12">
                                <?php echo Form::text('search', '', ['class'=>'col-md-12 form-input-text',
                                                'placeholder'=>'Search news']); ?>

                            </div>


                            <div class="col-md-12 mt-4 pb-1" style="border-bottom:2px solid red;">
                                <?php echo Form::submit('Search', ['class'=>'col-md-2 offset-5 btn btn-primary']); ?>

                            </div>
                            <hr>
                </div>
                        <?php echo Form::close(); ?>

            </div>

            <div class="col-md-12">
                <div class="row">
                    <?php
                        $news_array= News::all();
                    ?>

                    <div class="col-md-12">
                            <table class="table" >

                                    <th style="border-bottom:3px solid grey;"> ID </th>
                                    <th style="border-bottom:3px solid grey;"> Title </th>
                                    <th style="border-bottom:3px solid grey;"> Created </th>
                                    <th style="border-bottom:3px solid grey;"> Modify </th>

                                <?php $__currentLoopData = $news_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="bg-light" style="border-bottom:10px solid grey;" >
                                            <td class="text-danger" style="font-weight:bold;"><?php echo e($news->id); ?></td>

                                            <td style="font-weight:bold; font-size:14px;">
                                                <a style=" color:red;" href="<?php echo e(route('show.news.indv', $news->id)); ?>">
                                                    <?php echo e($news->title); ?>

                                                </a>
                                            </td>

                                            <td class="text-danger"><?php echo e(Carbon\Carbon::parse($news->created_at)->format('d/m/Y')); ?></td>

                                            <td class="text-danger" style="font-weight:bold;">
                                                <a href="<?php echo e(route('show.news.indv', $news->id)); ?>"  style="text-decoration: none;">
                                                    <span class="badge badge-pill badge-info" style="padding:5px;">View</span>
                                                </a>
                                                <a href="<?php echo e(route('show.edit',$news->id)); ?>">
                                                    <span class="badge badge-pill badge-warning" style="padding:5px;">Edit</span>
                                                </a>
                                                <a href="<?php echo e(route('delete.news',$news->id)); ?>" onclick="return confirm('Are You Sure To Delete?')"
                                                                class="badge badge-pill badge-danger">
                                                    Delete
                                                </a>

                                           </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </table>

                    </div>

                </div>
            </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout-backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>