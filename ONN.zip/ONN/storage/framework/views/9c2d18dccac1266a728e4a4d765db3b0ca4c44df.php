<?php $__env->startSection('content'); ?>

<script src="/vendor/laravel-filemanager/js/lfm.js"></script>


<?php if(Session::has('edit_success')): ?>
<?php
    $msg= Session::get('edit_success');

?>
<script type="text/javascript">
    var msg="<?php echo $msg ?>";
    alert(msg);
</script>
<?php endif; ?>


<div class="col-md-10" >
    <?php
        $news= News::find($id);
    ?>
    <div class="card mt-2" style="	background:#D1EEEE">
        <h5 class="card-header text-center text-danger">Edit News</h5>

        <?php if(count($errors)!=0): ?>
            <div class="row mt-2">
                    <div class="col-md-12 text-center ">
                        <h5 class="card-header text-danger">The Following errors occured</h5>
                    </div>
            </div>

        <?php endif; ?>

            <?php if(!is_null(LogicHelper::generateErrorDiv($errors))): ?>

                <?php $__currentLoopData = LogicHelper::generateErrorDiv($errors); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        echo($error);
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
        <div class="card-body">

            <?php echo Form::open(['route'=>'post.edit']); ?>



            <?php echo Form::label('news_title', 'Title', ['class'=>'col-md-2 text-danger form-label']); ?>



            <?php echo Form::text('news_title', $news->title,['class'=>'col-md-9 form-input-text']); ?>



<hr>
            <?php echo Form::label('news_short_desc', 'Short Desc (100 words max)',
                            ['class'=>'col-md-6 text-danger form-label']); ?>



            <?php echo Form::textarea('news_short_desc', $news->short_desc,
                        ['class'=>'col-md-10 offset-1 text-danger form-input-textarea']); ?>


<hr>


            <div class="row mt-2 mb-2">
                    <div class="input-group">
                        <span class="input-group-btn">
                        <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary">
                            <i class="fa fa-picture-o"></i> Change News Display Image
                        </a>
                        </span>
                        <input id="thumbnail" class="form-control " type="text" value="<?php echo e($news->image_path); ?>" style="color:red; font-weight:bold;" name="filepath" readonly >
                    </div>
                    <img id="holder" style="margin-top:15px; max-height:100px;" src="<?php echo e($news->image_path); ?>">
            </div>

            <?php echo Form::label('news_story', 'Story', ['class'=>'col-md-2 text-danger form-label']); ?>


            <?php echo Form::textarea('news_story', $news->story,
                        ['class'=>'col-md-10 offset-1 text-danger', 'id'=>'editor']); ?>

<hr>


            <?php echo Form::label('news_category', 'Select Category', ['class'=>'col-md-3 text-danger form-label']); ?>



            <?php echo Form::select('news_category',
                ['m'=>'Minority', 'f'=>'Free Speech','d'=>'Democracy', 'w'=>'Women & Children' ],'',
                        ['class'=>'col-md-5  form-input-text', 'id'=>'news_category']); ?>


            <!-- tag options -->
                <div class="row bg-light">
                    <div class="col-md-12 text-danger text-center">
                        <strong>Edit Tags</strong> <hr>
                    </div>
                    <?php
                        $index=0;
                    ?>

                    <?php
                        $loaded_tags=  LogicHelper::loadTags($news);
                        $tags_all= LogicHelper::getTagList();
                    ?>

                     <?php $__currentLoopData = $tags_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo Form::label('tag_'.($index+1), $tag, ['class'=>'col-md-3 form-label text-right']); ?>

                        <?php if(in_array($tag,$loaded_tags) ): ?>
                                <?php echo Form::checkbox('tag_'.($index+1), '',true, [' class'=>'col-md-1 mt-2']); ?>

                            <?php else: ?>
                                <?php echo Form::checkbox('tag_'.($index+1), '',false, [' class'=>'col-md-1 mt-2']); ?>


                        <?php endif; ?>

                        <?php
                            $index++;
                        ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            <!-- end tag options -->

            <div class="row bg-info mt-2">
                <?php echo Form::label('is_featured', 'Is Featured News?', ['class'=>'col-md-3 offset-3', 'style'=>'color:white; font-weight:bold; text-align:right;']); ?>


                <?php if($news->is_featured=='Y'): ?>
                    <?php echo Form::checkbox('is_featured', '', true, ['class'=>'col-md-1 mt-2']); ?>

                <?php else: ?>
                    <?php echo Form::checkbox('is_featured', '', false, ['class'=>'col-md-1 mt-2']); ?>

                <?php endif; ?>
            </div>

                <?php echo Form::hidden('id', $news->id); ?>


            <?php echo Form::submit('Update', ['class'=>'col-md-2 offset-5 mt-4  btn btn-success']); ?>



            <?php echo Form::close(); ?>


        </div>
    </div>

</div>



<script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>

<script type="text/javascript">
    CKEDITOR.replace('editor',{
        filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
    //  filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=',
        filebrowserBrowseUrl: '/laravel-filemanager?type=Files',
        //config.removeModules = 'UploadFileButton';
    // filebrowserUploadUrl: '/laravel-filemanager/upload?type=Files&_token='
        /*
        filebrowserBrowseUrl : '/ckfinder/ckfinder.html',
        filebrowserImageBrowseUrl : '/ckfinder/ckfinder.html?Type=Images',
        filebrowserFlashBrowseUrl : '/ckfinder/ckfinder.html?Type=Flash',
        filebrowserUploadUrl : '/ckfinder/core/connector/aspx/connector.aspx?command=QuickUpload&type=Files',
        filebrowserImageUploadUrl : '/ckfinder/core/connector/aspx/connector.aspx?command=QuickUpload&type=Images',
        filebrowserFlashUploadUrl : '/ckfinder/core/connector/aspx/connector.aspx?command=QuickUpload&type=Flash'
*/
    });

</script>


<script>
            $(document).ready(function() {
                    var $category= <?php echo json_encode($news->category->description); ?>;
                    console.log($category)
                    switch($category){
                        case('Women & Children'):
                        $('#news_category option[value="w"]').prop({defaultSelected: true});
                        break;

                        case('Minority'):
                        $('#news_category option[value="m"]').prop({defaultSelected: true});
                        break;

                        case('Free Speech'):
                        $('#news_category option[value="f"]').prop({defaultSelected: true});
                        break;

                        case('Democracy'):
                        $('#news_category option[value="d"]').prop({defaultSelected: true});
                        break;
                    }

                    $('#lfm').filemanager('image')


              });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout-backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>