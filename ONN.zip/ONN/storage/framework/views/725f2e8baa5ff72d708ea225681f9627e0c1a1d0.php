<?php $__env->startSection('content'); ?>

    <div class="col-md-10 mt-2">
        <?php
            $news= News::find($id);
        ?>
            <div class="col-md-12 card">
                <div class="row">
                    <div class="col-md-12 card-header" style="color:orangered; font-weight:bold;">
                        <span class="badge badge-success" style="padding:10px;">
                                <a href="<?php echo e(route('show.news')); ?>">
                                    <i class=" fa fa-hand-o-left fa-lg" style="color:white;"> Back</i>
                                </a>
                        </span>

                    </div>
                    <div class="col-md-12 card-header" style="color:orangered;">
                      <h4>
                          <?php echo e($news->title); ?>

                        </h4>
                    </div>

                    <div class="col-md-12 card-body">
                        <div class="row">
                            <div class="col-md-10 offset-1" style="font-weight: bold;
                                        font-size:13px; border-bottom:1px solid lightblue;
                                        padding-bottom:10px; margin-bottom:10px;">
                                <?php echo e($news->short_desc); ?>

                            </div>
                        </div>

                        <div class="col-md-12 mb-2" style="font-weight: bold; font-size:13px;
                                    padding:10px; border-bottom:1px solid lightblue; ">
                                Reported By: <?php echo e($news->posted_by); ?> Date: <?php echo e($news->created_at); ?> Updated at: <?php echo e($news->updated_at); ?>

                        </div>
                        <div class="col-md-12" style="font-weight: bold; font-size:13px;">
                            <?php echo e($news->story); ?>

                        </div>
                    </div>

                </div>
            </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout-backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>