<?php $__env->startSection('content'); ?>

<div class="col-md-10 card bg-light">

    <div class="col-md-9 card">

        <div class="row">
            <div class="col-md-12">
                <strong>
                        Add Tags
                </strong>
                <hr>
            </div>

            <?php echo Form::open(['route'=>'post.tags']); ?>


            <?php
                for($i=0; $i<5; $i++){
                    echo(Form::label('tag_field_'.($i+1), '', ['class'=>'col-md-3 text-right', 'style'=>'color:red; font-weight:bold']));
                    echo(Form::text('tag_field_'.($i+1), '', ['class'=>'col-md-7', 'placeholder'=>'Tag '.($i+1)]));
                }
            ?>


            <?php echo Form::submit('Save Tags', ['class'=>'col-md-4 offset-4 mt-3']); ?>


            <?php echo Form::close(); ?>


        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout-backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>