<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="card card-default">
                    <div class="card-header bg-warning text-center" style="color:white; font-weight:bold;" >Admin Login</div>
                    <?php if(Session::has('login_error')): ?>
                        <div class="alert alert-warning text-center" role="alert">
                           <strong style="color:red; font-weight:bold;">
                                <?php echo e(Session::get('login_error')); ?>

                        </strong>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('login.post')); ?>">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group<?php echo e($errors->has('user_id') ? ' has-error' : ''); ?>">
                                <label for="user_id" class="col-md-4 control-label">User ID</label>

                                <div class="col-md-6">
                                    <input id="user_id" type="text" class="form-control" name="user_id" value="<?php echo e(old('user_id')); ?>" required autofocus>

                                    <?php if($errors->has('user_id')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('user_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="col-md-4 control-label">Password</label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control" name="password" required>

                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        Login
                                    </button>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
