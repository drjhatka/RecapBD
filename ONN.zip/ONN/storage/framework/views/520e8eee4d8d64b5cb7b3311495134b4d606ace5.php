
  <!-- left menu -->
      <div class="col-md-2 sidebar">
          <ul>
              <li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
              <li><a href="<?php echo e(route('add.news')); ?>">Add News</a></li>
              <li><a href="<?php echo e(route('show.news')); ?>">View News</a></li>
              <li><a href="<?php echo e(route('add.editorial')); ?>">Add Editorial</a></li>
              <li><a href="<?php echo e(route('view.editorials')); ?>">View Editorials</a></li>
              <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
          </ul>
      </div>

