<?php $__env->startSection('content'); ?>


<div class="col-md-10">
    <div class="row">
        <div class="col-md-12 card">
            Add User
        </div>
        <div class="col-md-12">
            <?php echo Form::open(['route'=>'add.user']); ?>


            <?php echo Form::text('user_id', '', ['class'=>'col-md-4 mt-2', 'placeholder'=>'User ID']); ?>



            <?php echo Form::label('created_at', "Date", ['class'=>'col-md-2']); ?>


            <?php echo Form::date('created_at', Carbon\Carbon::now(), ['class'=>'col-md-4']); ?>


            <?php echo Form::label('password', "Password", ['class'=>'col-md-2']); ?>

            <?php echo Form::password('password', ['col-md-12']); ?>


            <?php echo Form::label('user_name', "User Name", ['class'=>'col-md-2']); ?>


            <?php echo Form::text('user_name','', ['class'=>'col-md-4 mt-2', 'placeholder'=>'User Name']); ?>




            <?php echo Form::submit('Add', ['class'=>'col-md-3  offset-2 mt-2 btn btn-primary']); ?>



            <?php echo Form::close(); ?>


        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout-backend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>